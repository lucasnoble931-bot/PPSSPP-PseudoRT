#ifdef GL_ES
precision mediump float;
precision mediump int;
#endif
attribute vec4 a_position;
attribute vec2 a_texcoord0;
uniform sampler2D sampler0;
uniform sampler2D sampler2;
uniform vec2 u_texelDelta;
uniform vec4 u_setting;
uniform vec4 u_timeDelta;
varying vec2 v_texcoord0;
varying vec4 v_states;       // radiance state, night state, radiance strength, reflection strength
varying vec4 v_nightParams;  // grade, exposure, gamma, night-blend gate
varying vec4 v_offsets;      // dx, dy, dxy.x, dxy.y

float luminance(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

float chroma(vec3 c) {
    float hi = max(c.r, max(c.g, c.b));
    float lo = min(c.r, min(c.g, c.b));
    return hi - lo;
}

vec3 sampleCurrent(vec2 uv) {
    return texture2D(sampler0, clamp(uv, vec2(0.001), vec2(0.999))).rgb;
}

float blueCyanHueScore(vec3 c) {
    float chromaValue = chroma(c);
    float greenBlue = min(c.g, c.b);
    float chromaMask = smoothstep(0.075, 0.20, chromaValue);
    float blue = smoothstep(0.08, 0.23, c.b - c.r)
               * smoothstep(0.12, 0.36, c.b);
    float cyan = smoothstep(0.05, 0.17, greenBlue - c.r)
               * smoothstep(0.12, 0.34, greenBlue);
    return clamp(max(blue, cyan) * chromaMask, 0.0, 1.0);
}

float nearBlackScore(vec3 c) {
    float maxChannel = max(c.r, max(c.g, c.b));
    return 1.0 - smoothstep(0.045, 0.22, maxChannel);
}

float decodeState(float a) {
    float valid = step(0.19, a) * (1.0 - step(0.82, a));
    return clamp((a - 0.20) / 0.60, 0.0, 1.0) * valid;
}

float smoothState(float previous, float target, float dt, float riseSeconds, float fallSeconds) {
    float rise = 1.0 - exp(-dt / riseSeconds);
    float fall = 1.0 - exp(-dt / fallSeconds);
    float blend = mix(fall, rise, step(previous, target));
    return clamp(previous + (target - previous) * blend, 0.0, 1.0);
}

void main() {
    gl_Position = a_position;
    v_texcoord0 = a_texcoord0;

    // V17's same nine sky probes and exact hue/coverage calculation.
    vec3 s0 = sampleCurrent(vec2(0.08, 0.045));
    vec3 s1 = sampleCurrent(vec2(0.29, 0.045));
    vec3 s2 = sampleCurrent(vec2(0.50, 0.045));
    vec3 s3 = sampleCurrent(vec2(0.71, 0.045));
    vec3 s4 = sampleCurrent(vec2(0.92, 0.045));
    vec3 s5 = sampleCurrent(vec2(0.15, 0.15));
    vec3 s6 = sampleCurrent(vec2(0.38, 0.15));
    vec3 s7 = sampleCurrent(vec2(0.62, 0.15));
    vec3 s8 = sampleCurrent(vec2(0.85, 0.15));

    float b0 = blueCyanHueScore(s0);
    float b1 = blueCyanHueScore(s1);
    float b2 = blueCyanHueScore(s2);
    float b3 = blueCyanHueScore(s3);
    float b4 = blueCyanHueScore(s4);
    float b5 = blueCyanHueScore(s5);
    float b6 = blueCyanHueScore(s6);
    float b7 = blueCyanHueScore(s7);
    float b8 = blueCyanHueScore(s8);
    float blueCoverage = (b0+b1+b2+b3+b4+b5+b6+b7+b8) / 9.0;

    // V17's exact whole-screen 4x4 darkness grid and scoring equations.
    float blackProximitySum = 0.0;
    float lowLumaSum = 0.0;
    float meanLumaSum = 0.0;
    for (int gy = 0; gy < 4; ++gy) {
        for (int gx = 0; gx < 4; ++gx) {
            vec2 sceneUV = (vec2(float(gx), float(gy)) + vec2(0.5)) * 0.25;
            vec3 sceneSample = sampleCurrent(sceneUV);
            float sceneLuma = luminance(sceneSample);
            blackProximitySum += nearBlackScore(sceneSample);
            lowLumaSum += 1.0 - smoothstep(0.045, 0.24, sceneLuma);
            meanLumaSum += sceneLuma;
        }
    }
    float blackProximity = blackProximitySum / 16.0;
    float lowLumaCoverage = lowLumaSum / 16.0;
    float meanSceneLuma = meanLumaSum / 16.0;

    float blackMajoritySignal = smoothstep(0.48, 0.72, blackProximity);
    float overallDimSignal = 1.0 - smoothstep(0.12, 0.30, meanSceneLuma);
    float lowLumaSignal = smoothstep(0.42, 0.70, lowLumaCoverage);
    float nightTarget = blackMajoritySignal * mix(0.68, 1.0, max(overallDimSignal, lowLumaSignal));
    nightTarget *= 1.0 - smoothstep(0.20, 0.46, blueCoverage);

    float skyLumaSum = b0*luminance(s0) + b1*luminance(s1) + b2*luminance(s2)
                     + b3*luminance(s3) + b4*luminance(s4) + b5*luminance(s5)
                     + b6*luminance(s6) + b7*luminance(s7) + b8*luminance(s8);
    float skyScoreSum = b0+b1+b2+b3+b4+b5+b6+b7+b8;
    float detectedSkyLuma = skyLumaSum / max(skyScoreSum, 0.001);
    float coverageState = smoothstep(0.12, 0.36, blueCoverage);
    float darkToNormal = smoothstep(0.10, 0.42, detectedSkyLuma);
    float normalToBright = smoothstep(0.38, 0.72, detectedSkyLuma);
    float brightnessWeight = 0.28 + 0.52 * darkToNormal + 0.20 * normalToBright;
    float radianceTarget = coverageState * brightnessWeight;

    // Use the same previous-frame metadata, timing clamps and rise/fall constants as V17.
    float previousRadiance = decodeState(texture2D(sampler2, vec2(0.005, 0.005)).a);
    float previousNight = decodeState(texture2D(sampler2, vec2(0.025, 0.005)).a);
    float dt = clamp(u_timeDelta.y, 0.0083, 0.05);
    float fadeSeconds = clamp(u_setting.z, 0.4, 3.0);
    float grade = clamp(u_setting.w, 0.0, 1.5);
    v_states = vec4(
        smoothState(previousRadiance, radianceTarget, dt, 0.20, fadeSeconds),
        smoothState(previousNight, nightTarget, dt, 0.26, 0.42),
        clamp(u_setting.x, 0.0, 1.0),
        clamp(u_setting.y, 0.0, 1.0)
    );
    v_nightParams = vec4(grade, pow(0.52, grade), 1.0 + 0.30 * grade,
                         smoothstep(0.01, 0.08, grade));
    v_offsets = vec4(
        max(u_texelDelta.x, 0.00025) * 3.0,
        max(u_texelDelta.y, 0.00025) * 3.0,
        max(u_texelDelta.x, 0.00025) * 4.5,
        max(u_texelDelta.y, 0.00025) * 4.5
    );
}
