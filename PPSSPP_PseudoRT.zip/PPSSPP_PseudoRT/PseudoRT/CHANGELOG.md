# Changelog — V22

- Based on the supplied V17 shader.
- Moved the exact global scene-classification and temporal-state calculations from fragment stage to vertex stage.
- Preserved detection probes, positions, thresholds, equations, smoothing, local-light samples/offsets, effect math and all INI settings.
- Requires vertex texture fetch support; handset/backend validation remains necessary.
