#ifdef GL_ES
precision mediump float;
precision mediump int;
#endif

uniform sampler2D sampler0;
varying vec2 v_texcoord0;
varying vec4 v_states;
varying vec4 v_nightParams;
varying vec4 v_offsets;

float luminance(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

float chroma(vec3 c) {
    float hi = max(c.r, max(c.g, c.b));
    float lo = min(c.r, min(c.g, c.b));
    return hi - lo;
}

vec3 sampleCurrent(vec2 uv) {
    return texture2D(sampler0, clamp(uv, vec2(0.001), vec2(0.999))).rgb;
}

// Compute both light responses from one luminance/chroma evaluation per sample.
// The original thresholds and response equations are unchanged.
void lightEnergyPair(vec3 c, out float dayEnergy, out float nightEnergy) {
    float l = luminance(c);
    float ch = chroma(c);
    float dayBright = smoothstep(0.58, 0.88, l);
    float dayNeutral = 1.0 - smoothstep(0.16, 0.40, ch);
    float nightBright = smoothstep(0.16, 0.48, l);
    float nightNeutral = 1.0 - smoothstep(0.20, 0.48, ch);
    dayEnergy = dayBright * (0.35 + 0.65 * dayNeutral);
    nightEnergy = nightBright * (0.48 + 0.52 * nightNeutral);
}

vec3 applyDayRadiance(vec3 base, float state, float strength) {
    float baseLuma = luminance(base);
    float midtoneResponse = 0.35 + 0.65 * (1.0 - smoothstep(0.25, 0.93, baseLuma));
    float radianceGain = min(state * 1.25, 1.25);
    float ambient = radianceGain * strength * 0.075 * midtoneResponse;
    vec3 result = base * (1.0 + radianceGain * strength * 0.025);
    result += vec3(0.93, 0.975, 1.0) * ambient;
    return result;
}

vec3 applyNightGrade(vec3 source, float grade, float exposure, float gamma) {
    float l = luminance(source);

    // Exposure and gamma are constant across the frame and precomputed in the vertex stage.
    vec3 graded = pow(max(source * exposure, vec3(0.0001)), vec3(gamma));

    // Preserve and lift real bright pixels relative to the dark scene. The mask
    // favors bright, neutral/white/yellow-ish pixels, but keeps some colored lamps.
    float neutral = 1.0 - smoothstep(0.18, 0.48, chroma(source));
    float highlightMask = smoothstep(0.24, 0.76, l) * (0.58 + 0.42 * neutral);
    float highlightGain = grade * (0.35 + 0.45 * highlightMask);
    graded += source * highlightMask * highlightGain;

    // Restrained cool shadow bias; highlights retain their original color.
    float shadowMask = 1.0 - smoothstep(0.18, 0.62, l);
    graded *= mix(vec3(1.0), vec3(0.78, 0.86, 1.0), shadowMask * grade * 0.16);

    // A subtle vignette adds depth without replacing the exposure/contrast grade.
    vec2 p = (v_texcoord0 - vec2(0.5)) * vec2(1.0, 0.82);
    float vignette = smoothstep(0.34, 0.84, length(p));
    graded *= 1.0 - vignette * (0.10 * grade);
    return clamp(graded, 0.0, 1.0);
}

void main() {
    vec2 uv = v_texcoord0;
    vec3 base = sampleCurrent(uv);

    float radianceState = v_states.x;
    float nightState = v_states.y;
    float radianceStrength = v_states.z;
    float reflectionStrength = v_states.w;
    float nightBlend = nightState * v_nightParams.w;

    // Uniform branch: skip an entire night-grade path when its blend is exactly zero,
    // and skip day radiance when night fully replaces it. Detection is unaffected.
    vec3 result;
    if (nightBlend <= 0.0) {
        result = applyDayRadiance(base, radianceState, radianceStrength);
    } else if (nightBlend >= 1.0) {
        result = applyNightGrade(base, v_nightParams.x, v_nightParams.y, v_nightParams.z);
    } else {
        vec3 dayResult = applyDayRadiance(base, radianceState, radianceStrength);
        vec3 nightResult = applyNightGrade(base, v_nightParams.x, v_nightParams.y, v_nightParams.z);
        result = mix(dayResult, nightResult, nightBlend);
    }

    // Independent local-light pass. Daytime keeps the former neutral highlight
    // response; at night, a lower energy threshold lets headlamps/lamp spill glow.
    if (reflectionStrength > 0.0) {
        vec2 dx = vec2(v_offsets.x, 0.0);
        vec2 dy = vec2(0.0, v_offsets.y);
        vec2 dxy = v_offsets.zw;

        vec3 cL = sampleCurrent(uv - dx);
        vec3 cR = sampleCurrent(uv + dx);
        vec3 cU = sampleCurrent(uv - dy);
        vec3 cD = sampleCurrent(uv + dy);
        vec3 cUL = sampleCurrent(uv - dxy);
        vec3 cUR = sampleCurrent(uv + vec2(dxy.x, -dxy.y));
        vec3 cDL = sampleCurrent(uv + vec2(-dxy.x, dxy.y));
        vec3 cDR = sampleCurrent(uv + dxy);

        float dL, nL, dR, nR, dU, nU, dD, nD, dUL, nUL, dUR, nUR, dDL, nDL, dDR, nDR;
        lightEnergyPair(cL, dL, nL);
        lightEnergyPair(cR, dR, nR);
        lightEnergyPair(cU, dU, nU);
        lightEnergyPair(cD, dD, nD);
        lightEnergyPair(cUL, dUL, nUL);
        lightEnergyPair(cUR, dUR, nUR);
        lightEnergyPair(cDL, dDL, nDL);
        lightEnergyPair(cDR, dDR, nDR);
        float dayLocal = (dL+dR+dU+dD) * 0.16 + (dUL+dUR+dDL+dDR) * 0.09;
        float nightLocal = (nL+nR+nU+nD) * 0.16 + (nUL+nUR+nDL+nDR) * 0.09;
        float localLight = mix(dayLocal, nightLocal, nightBlend);
        float localGain = mix(0.12, 0.30, clamp(nightBlend, 0.0, 1.0));
        float avoidClip = 1.0 - smoothstep(0.82, 0.99, luminance(result));
        result += vec3(1.0, 0.99, 0.965) * localLight * reflectionStrength * localGain * avoidClip;
    }

    // Store two independent controller values in alpha at tiny corner patches.
    // RGB in those pixels is left untouched; these markers are not visible.
    float radiancePatch = (1.0 - step(0.010, uv.x)) * (1.0 - step(0.010, uv.y));
    float nightPatch = step(0.020, uv.x) * (1.0 - step(0.030, uv.x))
                     * (1.0 - step(0.010, uv.y));
    float outputAlpha = 1.0;
    outputAlpha = mix(outputAlpha, 0.20 + 0.60 * radianceState, radiancePatch);
    outputAlpha = mix(outputAlpha, 0.20 + 0.60 * nightState, nightPatch);

    gl_FragColor = vec4(clamp(result, 0.0, 1.0), outputAlpha);
}
